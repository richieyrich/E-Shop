from django.shortcuts import render,redirect
from store.models import Product
from django.views import View


class Cart(View):
    def get(self,request):
        cart = request.session.get('cart')
        product_ids = list(cart.keys())
        print(product_ids)
        products = Product.get_products_by_id( product_ids)
        print(products)
        return render(request, 'store/cart.html',{'products': products})



