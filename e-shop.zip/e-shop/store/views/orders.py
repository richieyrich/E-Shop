from django.shortcuts import render,redirect
from store.models import Product,Order, Customer
from django.views import View
#from store.middleware.auth import Auth_Middleware
#from django.utils.decorators import method_decorator

class OrderView(View):
    #@method_decorator(Auth_Middleware)
    def get(self, request):
        customer_id = request.session.get('customer_id')
        print(customer_id)
        orders = Order.get_orders_by_customer(customer_id)
        data = {'orders': orders}
        return render(request, 'store/orders.html',data)