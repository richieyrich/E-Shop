from django.shortcuts import render,redirect
from store.models import  Customer
from django.contrib.auth.hashers  import make_password, check_password
from django.views import View



class Signup(View):
    def get(self, request):
        return render(request,'store/signup.html')

    def post(self, request):
        postdata = request.POST
        fname = postdata.get('firstname')
        lname = postdata.get('lastname')
        phone = postdata.get('phone')
        email = postdata.get('email')
        password = postdata.get('password')

        customer = Customer(first_name=fname, last_name=lname, phone=phone, email=email,password=password)
        #validations
        values = {'fname':fname, 'lname':lname, 'phone':phone, 'email':email}
        error_message = self.validate(customer)

        #saving
        if not error_message:
            customer.password = make_password(customer.password)
            customer.save()
            return redirect('home')
        else:
            data = {'error_message': error_message, 'values':values}
            return render(request,'store/signup.html', data)
    
    
    def validate(self,customer):
        error_message = None
        if not customer.first_name:
            error_message = 'no first name'
        elif len(customer.first_name)<2:
            error_message = 'first name less than 2 charctrs'
        elif not customer.last_name:
            error_message = 'no last name'
        elif len(customer.last_name)<2:
            error_message = 'last name less than 2 charctrs'
        elif not customer.phone:
            error_message = 'no lphone'
        elif len(customer.phone)<2:
            error_message = 'phone less than 2 charctrs'
        elif not customer.email:
            error_message = 'no email'
        elif len(customer.password)<2:
            error_message = 'password less than 2 charctrs'
        elif customer.is_exists():
            error_message = 'email exists'
        return error_message
