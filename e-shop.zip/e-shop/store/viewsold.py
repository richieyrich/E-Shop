from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import Product, Category, Customer
from django.contrib.auth.hashers  import make_password, check_password
from django.views import View



# Create your views here.

def index(request):
    products = None
    categories = Category.get_all_categories()
    category_id = request.GET.get('category')
    if category_id:
        products = Product.get_all_products_by_category_id(category_id)
    else:
        products = Product.get_all_products()

    data = {'products': products, 'categories': categories}
    return render(request,'store/index.html', data)
'''
#validate function
def validate(customer):
    error_message = None
    if not customer.first_name:
        error_message = 'no first name'
    elif len(customer.first_name)<2:
        error_message = 'first name less than 2 charctrs'
    elif not customer.last_name:
        error_message = 'no last name'
    elif len(customer.last_name)<2:
        error_message = 'last name less than 2 charctrs'
    elif not customer.phone:
        error_message = 'no lphone'
    elif len(customer.phone)<2:
        error_message = 'phone less than 2 charctrs'
    elif not customer.email:
        error_message = 'no email'
    elif len(customer.password)<2:
        error_message = 'password less than 2 charctrs'
    elif customer.is_exists():
        error_message = 'email exists'
    return error_message

#register
def register_user(request):
    postdata = request.POST
    fname = postdata.get('firstname')
    lname = postdata.get('lastname')
    phone = postdata.get('phone')
    email = postdata.get('email')
    password = postdata.get('password')

    customer = Customer(first_name=fname, last_name=lname, phone=phone, email=email,password=password)
    #validations
    values = {'fname':fname, 'lname':lname, 'phone':phone, 'email':email}
    
    error_message = validate(customer)

    #saving
    if not error_message:
        customer.password = make_password(customer.password)
        customer.save()
        return redirect('home')
    else:
        data = {'error_message': error_message, 'values':values}
        return render(request,'store/signup.html', data)
'''

class Signup(View):
    def get(self, request):
        return render(request,'store/signup.html')

    def post(self, request):
        postdata = request.POST
        fname = postdata.get('firstname')
        lname = postdata.get('lastname')
        phone = postdata.get('phone')
        email = postdata.get('email')
        password = postdata.get('password')

        customer = Customer(first_name=fname, last_name=lname, phone=phone, email=email,password=password)
        #validations
        values = {'fname':fname, 'lname':lname, 'phone':phone, 'email':email}
        error_message = self.validate(customer)

        #saving
        if not error_message:
            customer.password = make_password(customer.password)
            customer.save()
            return redirect('home')
        else:
            data = {'error_message': error_message, 'values':values}
            return render(request,'store/signup.html', data)
    
    
    def validate(self,customer):
        error_message = None
        if not customer.first_name:
            error_message = 'no first name'
        elif len(customer.first_name)<2:
            error_message = 'first name less than 2 charctrs'
        elif not customer.last_name:
            error_message = 'no last name'
        elif len(customer.last_name)<2:
            error_message = 'last name less than 2 charctrs'
        elif not customer.phone:
            error_message = 'no lphone'
        elif len(customer.phone)<2:
            error_message = 'phone less than 2 charctrs'
        elif not customer.email:
            error_message = 'no email'
        elif len(customer.password)<2:
            error_message = 'password less than 2 charctrs'
        elif customer.is_exists():
            error_message = 'email exists'
        return error_message

'''
def signup(request):
    if request.method == 'GET':
         return render(request,'store/signup.html')
    else:
        return register_user(request)
'''

class Login(View):
    def get(self, request):
        return render(request, 'store/login.html')

    def post(self, request):
        email = request.POST.get('email')
        password = request.POST.get('password')
        customer = Customer.get_customer_by_mail(email)
        error_message = None
        if customer:
            if check_password(password, customer.password):
                return redirect('home')
            else:
                error_message = 'invalid credentials'
        else:
            error_message = 'invalid credentials'
        return render(request, 'store/login.html',{'error_message':error_message})

'''
def login(request):
    if request.method == 'GET':
        return render(request, 'store/login.html')
    else:
        email = request.POST.get('email')
        password = request.POST.get('password')
        customer = Customer.get_customer_by_mail(email)
        error_message = None
        if customer:
            if check_password(password, customer.password):
                return redirect('home')
            else:
                error_message = 'invalid credentials'
        else:
            error_message = 'invalid credentials'
        return render(request, 'store/login.html',{'error_message':error_message})'''