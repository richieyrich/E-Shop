from django import template

register = template.Library()

@register.filter(name='is_in_cart')
def is_in_cart(product, cart):
    keys = cart.keys()
    product_id = str(product.id)
    if product_id in keys:
        return True
    else:
        return False


@register.filter(name='cart_count')
def cart_count(product, cart):
    keys = cart.keys()
    product_id = str(product.id)
    if product_id in keys:
        return cart[product_id]
    else:
        return False


@register.filter(name='price_total')
def price_total(product, cart):
    total = product.price * cart_count(product, cart)
    return total

@register.filter(name='total_cart_price')
def total_cart_price(products, cart):
    sum = 0
    for product in products:
        sum += price_total(product,cart)
    return sum

